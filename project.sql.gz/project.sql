-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Jun 11, 2023 at 02:40 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_order`
--

CREATE TABLE `customer_order` (
  `Product_id` int(11) DEFAULT NULL,
  `Product_brand` varchar(50) DEFAULT NULL,
  `Product_color` varchar(50) DEFAULT NULL,
  `Shoe_size` decimal(4,1) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fk_id_color`
--

CREATE TABLE `fk_id_color` (
  `Product_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `color_no` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fk_id_color`
--

INSERT INTO `fk_id_color` (`Product_id`, `size_id`, `color_no`) VALUES
(800, 9, 1),
(800, 10, 3),
(800, 11, 6),
(800, 12, 9),
(800, 13, 5),
(810, 14, 6),
(810, 10, 7),
(810, 12, 1),
(810, 13, 1),
(820, 10, 3),
(820, 11, 6),
(820, 12, 8),
(820, 13, 6),
(830, 5, 1),
(830, 6, 1),
(840, 7, 8),
(840, 8, 14),
(850, 9, 11),
(850, 10, 10),
(850, 11, 12),
(850, 12, 13),
(850, 13, 6),
(860, 10, 14),
(860, 11, 13),
(860, 12, 12),
(860, 13, 10),
(870, 9, 5),
(870, 10, 2),
(870, 12, 1),
(870, 13, 9),
(890, 9, 8),
(890, 10, 9),
(890, 11, 7),
(890, 8, 6),
(890, 7, 4),
(800, 12, 9),
(810, 14, 3),
(810, 10, 2),
(810, 13, 8),
(820, 11, 5),
(820, 12, 4),
(830, 6, 14),
(840, 7, 6),
(850, 9, 3),
(850, 10, 10),
(850, 11, 11),
(850, 12, 10),
(860, 12, 9),
(860, 13, 6),
(870, 13, 5),
(890, 8, 3),
(1122, NULL, 2),
(132, NULL, 2),
(1992, 5, 7),
(900, 13, 3),
(600, NULL, 0),
(123, 5, 1),
(153, 10, 6);

-- --------------------------------------------------------

--
-- Table structure for table `fk_id_size`
--

CREATE TABLE `fk_id_size` (
  `product_id` int(11) DEFAULT NULL,
  `shoe_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fk_id_size`
--

INSERT INTO `fk_id_size` (`product_id`, `shoe_id`) VALUES
(800, 12),
(810, 14),
(810, 10),
(810, 13),
(820, 11),
(820, 12),
(830, 6),
(840, 7),
(840, 8),
(850, 9),
(850, 10),
(850, 11),
(850, 12),
(850, 13),
(860, 10),
(860, 11),
(860, 12),
(860, 13),
(870, 9),
(870, 10),
(870, 12),
(870, 13),
(890, 9),
(890, 10),
(890, 11),
(890, 8),
(1122, NULL),
(132, NULL),
(1992, 5),
(600, NULL),
(123, 5),
(153, 10);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(50) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `designation` varchar(50) DEFAULT 'customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `pass`, `designation`) VALUES
('muhammadafzalhashmi', 'f2021266252', 'Admin'),
('muhammadyousaf', 'f2021266253', 'Admin'),
('admin', 'admin', 'Admin'),
('muhammadhammadrazzaq', '$2y$10$mY0qs8iCN75s0z8QTeuKP.UR/RskZ8GQj6mDI6sp/PCWZOAF0Rcfy', 'customer'),
('muhammadwaleed', '$2y$10$JG8pfus.jbzGad9RIY5NW.fgeVoV0plEcX5rnBRq52V4yq8ltWLry', 'customer'),
('customer', '$2y$10$m/yJQlcynw82xp0s4DZ0aeVh0vmIob5S4SlOk./NfEIpzQmOzbfpy', 'customer');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_ID` int(11) NOT NULL,
  `product_brand` varchar(50) DEFAULT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `Date_Time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_ID`, `product_brand`, `product_name`, `Date_Time`) VALUES
(123, 'Nike', 'Air', '2023-06-08 11:09:00'),
(132, 'Nike', 'Air', '2023-06-08 11:41:34'),
(153, 'Puma', 'Michal Jordan', '2023-06-09 00:42:30'),
(600, 'cac', 'Jordan', '2023-06-08 17:15:38'),
(800, 'Nike', 'Air Max Plus', NULL),
(810, 'Nike', 'Air Jordan 1 Mid', NULL),
(820, 'Nike', 'Air Jordan 1 Low SE Craft', NULL),
(830, 'Nike', 'Court Borough Low 2 SE', NULL),
(840, 'Nike', 'Air Max Terrascape Plus', NULL),
(850, 'Nike', 'Air Jordan 1 Mid', NULL),
(860, 'Nike', 'Air Force 1 Low Retro', NULL),
(870, 'Nike', 'Air VaporMax 2021 FK', NULL),
(880, 'Nike', 'Air', '2023-06-08 11:03:35'),
(890, 'Nike', 'Air Jordan 1 Mid', NULL),
(900, 'Nike', 'Jordan', '2023-06-08 17:12:44'),
(1122, 'Nike', 'Air', '2023-06-08 11:39:26'),
(1992, 'Puma', 'Jordan', '2023-06-08 13:01:36');

-- --------------------------------------------------------

--
-- Table structure for table `searched_data`
--

CREATE TABLE `searched_data` (
  `product_id` int(11) DEFAULT NULL,
  `product_brand` varchar(50) DEFAULT NULL,
  `shoes_color` varchar(50) DEFAULT NULL,
  `shoes_size` decimal(4,1) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `searched_data`
--

INSERT INTO `searched_data` (`product_id`, `product_brand`, `shoes_color`, `shoes_size`, `price`) VALUES
(800, 'Nike', 'Beige', 9.5, 13000),
(820, 'Nike', 'Beige', 9.5, 5600),
(810, 'Nike', 'Beige', 12.0, 15410),
(900, 'Nike', 'Beige', 11.0, 3325);

-- --------------------------------------------------------

--
-- Table structure for table `shoe_color`
--

CREATE TABLE `shoe_color` (
  `color_no` int(11) NOT NULL,
  `shoe_color` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shoe_color`
--

INSERT INTO `shoe_color` (`color_no`, `shoe_color`) VALUES
(1, 'Black'),
(2, 'Blue'),
(3, 'Beige'),
(4, 'Brown'),
(5, 'Gray'),
(6, 'Cream'),
(7, 'White'),
(8, 'Pink'),
(9, 'Neon'),
(10, 'Red'),
(11, 'Tan'),
(12, 'Green'),
(13, 'Yellow'),
(14, 'Orange');

-- --------------------------------------------------------

--
-- Table structure for table `shoe_price`
--

CREATE TABLE `shoe_price` (
  `Product_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `color_no` int(11) DEFAULT NULL,
  `price` int(50) DEFAULT NULL,
  `Quantity` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shoe_price`
--

INSERT INTO `shoe_price` (`Product_id`, `size_id`, `color_no`, `price`, `Quantity`) VALUES
(800, 9, 1, 15000, 4),
(800, 10, 3, 13000, 4),
(800, 11, 6, 12000, 10),
(800, 12, 9, 19000, 15),
(800, 13, 5, 20000, 2),
(810, 14, 6, 5000, 9),
(810, 10, 7, 9000, 6),
(810, 12, 1, 19000, 5),
(810, 13, 1, 18888, 9),
(820, 10, 3, 5600, 3),
(820, 11, 6, 9850, 8),
(820, 12, 8, 16890, 100),
(820, 13, 6, 16589, 7),
(830, 5, 1, 15555, 3),
(830, 6, 1, 3000, 29),
(840, 7, 8, 4000, NULL),
(840, 8, 14, 9820, NULL),
(850, 9, 11, 10000, NULL),
(850, 10, 10, 13264, NULL),
(850, 11, 12, 12345, NULL),
(850, 12, 13, 54321, NULL),
(850, 13, 6, 23451, NULL),
(860, 10, 14, 6540, NULL),
(860, 11, 13, 2531, NULL),
(860, 12, 12, 15987, NULL),
(860, 13, 10, 12222, NULL),
(870, 9, 5, 19000, NULL),
(870, 10, 2, 20000, NULL),
(870, 12, 1, 2000, NULL),
(870, 13, 9, 15980, NULL),
(890, 9, 8, 6890, 4),
(890, 10, 9, 5600, NULL),
(890, 11, 7, 12000, NULL),
(890, 8, 6, 19000, NULL),
(890, 7, 4, 25000, NULL),
(800, 12, 9, 36540, 15),
(810, 14, 3, 15410, 8),
(810, 10, 2, 2153, 3),
(810, 13, 8, 21563, 20),
(820, 11, 5, 216510, 6),
(820, 12, 4, 666666, 6),
(830, 6, 14, 10000, 6),
(840, 7, 6, 10000, NULL),
(850, 9, 3, 13254, NULL),
(850, 10, 10, 36589, NULL),
(850, 11, 11, 156231, NULL),
(850, 12, 10, 12589, NULL),
(860, 12, 9, 11223, NULL),
(860, 13, 6, 15987, NULL),
(870, 13, 5, 13252, NULL),
(890, 8, 3, 13254, NULL),
(1992, 5, 7, 70000, 0),
(900, 13, 3, 3325, 124),
(123, 5, 1, 10000, 49),
(153, 10, 6, 15000, 5);

-- --------------------------------------------------------

--
-- Table structure for table `shoe_sizes`
--

CREATE TABLE `shoe_sizes` (
  `size_id` int(11) NOT NULL,
  `shoe_size` decimal(4,1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shoe_sizes`
--

INSERT INTO `shoe_sizes` (`size_id`, `shoe_size`) VALUES
(1, 4.0),
(2, 5.0),
(3, 6.0),
(4, 6.5),
(5, 7.0),
(6, 7.5),
(7, 8.0),
(8, 8.5),
(9, 9.0),
(10, 9.5),
(11, 10.0),
(12, 10.5),
(13, 11.0),
(14, 12.0),
(15, 13.0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fk_id_color`
--
ALTER TABLE `fk_id_color`
  ADD KEY `Product_id` (`Product_id`),
  ADD KEY `size_id` (`size_id`);

--
-- Indexes for table `fk_id_size`
--
ALTER TABLE `fk_id_size`
  ADD KEY `product_id` (`product_id`),
  ADD KEY `shoe_id` (`shoe_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_ID`);

--
-- Indexes for table `shoe_color`
--
ALTER TABLE `shoe_color`
  ADD PRIMARY KEY (`color_no`);

--
-- Indexes for table `shoe_price`
--
ALTER TABLE `shoe_price`
  ADD KEY `Product_id` (`Product_id`),
  ADD KEY `size_id` (`size_id`),
  ADD KEY `color_no` (`color_no`);

--
-- Indexes for table `shoe_sizes`
--
ALTER TABLE `shoe_sizes`
  ADD PRIMARY KEY (`size_id`),
  ADD UNIQUE KEY `shoe_size` (`shoe_size`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `fk_id_color`
--
ALTER TABLE `fk_id_color`
  ADD CONSTRAINT `fk_id_color_ibfk_1` FOREIGN KEY (`Product_id`) REFERENCES `product` (`product_ID`),
  ADD CONSTRAINT `fk_id_color_ibfk_2` FOREIGN KEY (`size_id`) REFERENCES `shoe_sizes` (`size_id`);

--
-- Constraints for table `fk_id_size`
--
ALTER TABLE `fk_id_size`
  ADD CONSTRAINT `fk_id_size_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_ID`),
  ADD CONSTRAINT `fk_id_size_ibfk_2` FOREIGN KEY (`shoe_id`) REFERENCES `shoe_sizes` (`size_id`);

--
-- Constraints for table `shoe_price`
--
ALTER TABLE `shoe_price`
  ADD CONSTRAINT `shoe_price_ibfk_1` FOREIGN KEY (`Product_id`) REFERENCES `product` (`product_ID`),
  ADD CONSTRAINT `shoe_price_ibfk_2` FOREIGN KEY (`size_id`) REFERENCES `shoe_sizes` (`size_id`),
  ADD CONSTRAINT `shoe_price_ibfk_3` FOREIGN KEY (`color_no`) REFERENCES `shoe_color` (`color_no`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
